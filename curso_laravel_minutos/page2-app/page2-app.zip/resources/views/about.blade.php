@extends('layout')

@section('content')
    <h1>Contenido de Acerca de</h1>
@endsection