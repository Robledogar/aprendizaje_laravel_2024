@extends('layout')

@section('content')
    <h1>Contenido de Contactos</h1>
@endsection