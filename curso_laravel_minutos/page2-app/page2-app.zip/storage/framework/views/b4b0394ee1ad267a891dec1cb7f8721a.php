<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

    <title>Laravel en minutos</title>
    
</head>
<body>
    <ul class="menu">
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('about')); ?>">Acerca de</a></li>
        <li><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
        <li><a href="<?php echo e(route('contact')); ?>">Contactos</a></li>
    </ul>

    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\aprendizaje_laravel_2024\curso_laravel_minutos\page2-app\resources\views/layout.blade.php ENDPATH**/ ?>