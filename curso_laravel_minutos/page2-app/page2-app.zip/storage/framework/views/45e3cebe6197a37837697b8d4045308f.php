

<?php $__env->startSection('content'); ?>
    <h1>Contenido de Home</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aprendizaje_laravel_2024\curso_laravel_minutos\page2-app\resources\views/home.blade.php ENDPATH**/ ?>