<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\aprendizaje_laravel_2024\curso_youtube_Aprendible\bootcamp-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>